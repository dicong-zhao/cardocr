
package com.example.cardocr.camera

import android.content.Context
import android.widget.Toast
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.example.cardocr.image.AutoCropper
import com.example.cardocr.ocr.TesseractManager

class CameraAnalyzer(private val context: Context) : ImageAnalysis.Analyzer {

    private val ocr = TesseractManager(context)

    override fun analyze(image: ImageProxy) {
        val bitmap = ImageUtils.toBitmap(image) ?: run {
            image.close(); return
        }

        val cropped = AutoCropper.cropCard(bitmap)
        if (cropped != null) {
            val digits = ocr.extractDigits(cropped)
            if (digits.length >= 6) {
                Toast.makeText(context, digits, Toast.LENGTH_SHORT).show()
            }
        }
        image.close()
    }
}
