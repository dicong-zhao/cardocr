
package com.example.cardocr.ocr

import android.content.Context
import android.graphics.Bitmap
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File

class TesseractManager(context: Context) {

    private val tess = TessBaseAPI()
    private val dataPath = context.filesDir.absolutePath

    init {
        val tessDir = File(dataPath, "tessdata")
        if (!tessDir.exists()) tessDir.mkdirs()

        val trained = File(tessDir, "eng.traineddata")
        if (!trained.exists()) {
            context.assets.open("tessdata/eng.traineddata")
                .copyTo(trained.outputStream())
        }

        tess.init(dataPath, "eng")
        tess.setVariable("tessedit_char_whitelist", "0123456789")
        tess.pageSegMode = TessBaseAPI.PageSegMode.PSM_SINGLE_LINE
    }

    fun extractDigits(bitmap: Bitmap): String {
        tess.setImage(bitmap)
        return tess.utF8Text.replace(Regex("\\D"), "")
    }
}
