
package com.example.cardocr.image

import android.graphics.Bitmap
import org.opencv.android.Utils
import org.opencv.core.*
import org.opencv.imgproc.Imgproc
import kotlin.math.max
import kotlin.math.hypot

object AutoCropper {

    fun cropCard(srcBitmap: Bitmap): Bitmap? {
        val src = Mat()
        Utils.bitmapToMat(srcBitmap, src)

        val gray = Mat()
        Imgproc.cvtColor(src, gray, Imgproc.COLOR_BGR2GRAY)
        Imgproc.GaussianBlur(gray, gray, Size(5.0, 5.0), 0.0)

        val edges = Mat()
        Imgproc.Canny(gray, edges, 75.0, 200.0)

        val contours = mutableListOf<MatOfPoint>()
        Imgproc.findContours(edges, contours, Mat(),
            Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)

        val contour = contours
            .map { MatOfPoint2f(*it.toArray()) }
            .maxByOrNull { Imgproc.contourArea(MatOfPoint(*it.toArray())) }
            ?: return null

        val peri = Imgproc.arcLength(contour, true)
        val approx = MatOfPoint2f()
        Imgproc.approxPolyDP(contour, approx, 0.02 * peri, true)

        if (approx.total() != 4L) return null
        return warp(src, approx)
    }

    private fun warp(src: Mat, c: MatOfPoint2f): Bitmap {
        val pts = c.toArray().sortedBy { it.x + it.y }
        val tl = pts[0]; val tr = pts[1]; val bl = pts[2]; val br = pts[3]

        val w = max(dist(br, bl), dist(tr, tl)).toInt()
        val h = max(dist(tr, br), dist(tl, bl)).toInt()

        val srcPts = MatOfPoint2f(tl, tr, br, bl)
        val dstPts = MatOfPoint2f(
            Point(0.0,0.0), Point(w.toDouble(),0.0),
            Point(w.toDouble(),h.toDouble()), Point(0.0,h.toDouble())
        )

        val m = Imgproc.getPerspectiveTransform(srcPts, dstPts)
        val out = Mat()
        Imgproc.warpPerspective(src, out, m, Size(w.toDouble(), h.toDouble()))

        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(out, bmp)
        return bmp
    }

    private fun dist(a: Point, b: Point) = hypot(a.x - b.x, a.y - b.y)
}
