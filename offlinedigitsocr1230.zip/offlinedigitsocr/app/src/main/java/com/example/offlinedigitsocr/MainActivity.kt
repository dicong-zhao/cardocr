package com.example.offlinedigitsocr

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.SurfaceTexture
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.util.Size
import android.view.Surface
import android.view.TextureView
import android.widget.Button
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private enum class Mode { CAMERA, SCREEN }

    private lateinit var textureView: TextureView
    private lateinit var btnCamera: Button
    private lateinit var btnScreen: Button

    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val ocrExecutor = Executors.newSingleThreadExecutor()

    private lateinit var ocr: OcrEngine
    private var mode: Mode = Mode.CAMERA

    // Detection rules (13..19 digits)
    private val MIN_CARD_LEN = 13
    private val MAX_CARD_LEN = 19
    private val STABLE_REQUIRED = 7

    // Throttle / stability
    private var lastOcrAt = 0L
    private var pauseOcrUntil = 0L
    private var lastShownDigits: String? = null
    private var stableDigits: String? = null
    private var stableCount = 0

    private var popup: AlertDialog? = null

    // CameraX
    private var cameraProvider: ProcessCameraProvider? = null

    // Screen capture
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var screenThread: HandlerThread? = null
    private var screenHandler: Handler? = null

    @Volatile private var screenBusy = false
    private var lastScreenFrameAt = 0L

    private val requestCameraPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) switchToCameraMode() else finish()
        }

    private val screenCaptureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                startScreenCapture(result.resultCode, result.data!!)
            } else {
                // user cancelled -> fallback
                switchToCameraMode()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)
        textureView = findViewById(R.id.textureView)
        btnCamera = findViewById(R.id.btnCamera)
        btnScreen = findViewById(R.id.btnScreen)

        ocr = OcrEngine(applicationContext)

        btnCamera.setOnClickListener { switchToCameraMode() }
        btnScreen.setOnClickListener { switchToScreenMode() }

        if (hasCameraPermission()) switchToCameraMode()
        else requestCameraPermission.launch(Manifest.permission.CAMERA)
    }

    private fun hasCameraPermission(): Boolean =
        ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun resetDetectionState() {
        lastOcrAt = 0L
        pauseOcrUntil = 0L
        lastShownDigits = null
        stableDigits = null
        stableCount = 0
    }

    // ---------------- CAMERA MODE ----------------
    private fun switchToCameraMode() {
        mode = Mode.CAMERA
        stopScreenCapture()
        resetDetectionState()
        startCamera()
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            cameraProvider = provider

            val preview = Preview.Builder().build()

            val analysis = ImageAnalysis.Builder()
                .setTargetResolution(Size(1280, 720))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()

            analysis.setAnalyzer(cameraExecutor) { imageProxy ->
                try {
                    val now = SystemClock.elapsedRealtime()
                    if (now < pauseOcrUntil) { imageProxy.close(); return@setAnalyzer }
                    if (now - lastOcrAt < 200) { imageProxy.close(); return@setAnalyzer }
                    lastOcrAt = now

                    val bmp = imageProxy.toBitmap()
                    imageProxy.close()

                    runDetectionOnBitmap(bmp)
                } catch (_: Throwable) {
                    try { imageProxy.close() } catch (_: Throwable) {}
                }
            }

            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)

            // Preview -> TextureView
            preview.setSurfaceProvider { request ->
                val st: SurfaceTexture? = textureView.surfaceTexture
                if (st == null) {
                    request.willNotProvideSurface()
                    return@setSurfaceProvider
                }
                val surface = Surface(st)
                request.provideSurface(surface, cameraExecutor) {
                    try { surface.release() } catch (_: Throwable) {}
                }
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun stopCamera() {
        cameraProvider?.unbindAll()
        cameraProvider = null
    }

    // ---------------- SCREEN MODE ----------------
    private fun switchToScreenMode() {
        mode = Mode.SCREEN
        stopCamera()
        resetDetectionState()
        requestScreenCapture()
    }

    private fun requestScreenCapture() {
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        screenCaptureLauncher.launch(mgr.createScreenCaptureIntent())
    }

    private fun startScreenCapture(resultCode: Int, data: Intent) {
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = mgr.getMediaProjection(resultCode, data)

        // HandlerThread required for API 23 compatibility (Executor overload is API 28+)
        screenThread = HandlerThread("screen-ocr").apply { start() }
        screenHandler = Handler(screenThread!!.looper)

        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        // Use PixelFormat for RGBA
        imageReader = ImageReader.newInstance(width, height, android.graphics.ImageFormat.YUV_420_888, 2)

        virtualDisplay = mediaProjection!!.createVirtualDisplay(
            "screen-ocr",
            width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface,
            null,
            screenHandler
        )

        imageReader!!.setOnImageAvailableListener(ImageReader.OnImageAvailableListener { reader ->
            val img = reader.acquireLatestImage() ?: return@OnImageAvailableListener

            try {
                val now = SystemClock.elapsedRealtime()

                // ✅ hard throttle for screen OCR (2.5 fps)
                if (now - lastScreenFrameAt < 400) return@OnImageAvailableListener
                lastScreenFrameAt = now

                // ✅ if still processing last frame, drop this frame
                if (screenBusy) return@OnImageAvailableListener
                screenBusy = true

                // Convert to bitmap (still heavy but ok if throttled)
                val bmpFull = img.toBitmap()

                // ✅ downscale before OCR (huge speed win)
                val targetW = 720
                val bmp = if (bmpFull.width > targetW) {
                    val newH = (bmpFull.height * (targetW.toFloat() / bmpFull.width)).toInt()
                    android.graphics.Bitmap.createScaledBitmap(bmpFull, targetW, newH, true)
                } else bmpFull

                // ✅ run OCR off the screen handler thread
                ocrExecutor.execute {
                    try {
                        runDetectionOnBitmap(bmp)
                    } finally {
                        screenBusy = false
                    }
                }
            } catch (_: Throwable) {
                screenBusy = false
            } finally {
                img.close()
            }
        }, screenHandler)
    }

    private fun stopScreenCapture() {
        imageReader?.setOnImageAvailableListener(null, null)
        imageReader?.close()
        imageReader = null

        virtualDisplay?.release()
        virtualDisplay = null

        mediaProjection?.stop()
        mediaProjection = null

        screenThread?.quitSafely()
        screenThread = null
        screenHandler = null
    }

    // ---------------- SHARED DETECTION ----------------
    private fun runDetectionOnBitmap(bmp: android.graphics.Bitmap) {
        ocrExecutor.execute {
            val rawDigits = try { ocr.extractDigits(bmp) } catch (_: Throwable) { null } ?: return@execute

            val candidate = when {
                rawDigits.length < MIN_CARD_LEN -> null
                rawDigits.length > MAX_CARD_LEN -> rawDigits.take(MAX_CARD_LEN)
                else -> rawDigits
            } ?: return@execute

            if (candidate == stableDigits) stableCount++ else {
                stableDigits = candidate
                stableCount = 1
            }

            if (stableCount >= STABLE_REQUIRED && candidate != lastShownDigits) {
                lastShownDigits = candidate

                pauseOcrUntil = SystemClock.elapsedRealtime() + 2000
                stableDigits = null
                stableCount = 0

                runOnUiThread { showPopup(formatCard(candidate)) }
            }
        }
    }

    private fun formatCard(card: String): String =
        card.chunked(4).joinToString(" ")

    private fun showPopup(text: String) {
        popup?.dismiss()
        popup = AlertDialog.Builder(this)
            .setTitle(if (mode == Mode.CAMERA) "Camera detected" else "Screen detected")
            .setMessage(text)
            .setPositiveButton("OK") { d, _ -> d.dismiss() }
            .setNeutralButton("Keep scanning") { d, _ -> d.dismiss() }
            .create()
        popup?.show()
    }

    override fun onDestroy() {
        super.onDestroy()
        popup?.dismiss()
        stopCamera()
        stopScreenCapture()
        cameraExecutor.shutdown()
        ocrExecutor.shutdown()
        try { ocr.close() } catch (_: Throwable) {}
    }
}