package com.example.offlinedigitsocr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File
import java.io.FileOutputStream

class OcrEngine(private val context: Context) {

    private val tess = TessBaseAPI()
    private val dataPath: String

    init {
        // App private dir: /data/data/<pkg>/files/tesseract/
        val dir = File(context.filesDir, "tesseract")
        dataPath = dir.absolutePath
        val tessdata = File(dir, "tessdata")
        if (!tessdata.exists()) tessdata.mkdirs()

        // Copy assets/tessdata/eng.traineddata -> files/tesseract/tessdata/eng.traineddata
        copyAssetIfMissing("tessdata/eng.traineddata", File(tessdata, "eng.traineddata"))

        // Init OCR
        // Use "eng". Model is bundled, so offline.
        tess.init(dataPath, "eng")

        // Restrict output to digits (whitelist) :contentReference[oaicite:4]{index=4}
        tess.setVariable("tessedit_char_whitelist", "0123456789")
        // Commonly helpful for single-line digits
        tess.pageSegMode = TessBaseAPI.PageSegMode.PSM_SINGLE_LINE
    }

    fun extractDigits(src: Bitmap): String? {
        // Scale up helps a LOT for screen-based cards
        val scaled = Bitmap.createScaledBitmap(src, src.width * 2, src.height * 2, true)

        // Lower threshold works better for screens
        val pre = threshold(grayscale(scaled), 120)

        tess.setImage(pre)

        val raw = tess.utF8Text ?: run {
            tess.clear()
            return null
        }

        tess.clear() // ✅ avoid state bleed between frames

        return raw.replace(Regex("[^0-9]"), "").takeIf { it.isNotBlank() }
    }

    fun close() {
        tess.end()
    }

    private fun copyAssetIfMissing(assetPath: String, outFile: File) {
        if (outFile.exists() && outFile.length() > 0) return
        context.assets.open(assetPath).use { input ->
            FileOutputStream(outFile).use { output ->
                input.copyTo(output)
            }
        }
    }

    private fun grayscale(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val c = src.getPixel(x, y)
                val r = Color.red(c)
                val g = Color.green(c)
                val b = Color.blue(c)
                val gray = (0.299 * r + 0.587 * g + 0.114 * b).toInt()
                out.setPixel(x, y, Color.rgb(gray, gray, gray))
            }
        }
        return out
    }

    private fun threshold(src: Bitmap, t: Int = 150): Bitmap {
        val w = src.width
        val h = src.height
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val c = src.getPixel(x, y)
                val v = Color.red(c) // already gray
                out.setPixel(x, y, if (v > t) Color.WHITE else Color.BLACK)
            }
        }
        return out
    }
}
